const axios = require('axios');
const fs = require('fs');

const getRandomInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

const updateScore = async (accessToken, accountIndex, userAgent) => {
    console.log(`[~] CoinSweeper Log:`);
    for (let i = 0; i < 5; i++) {
        const score = getRandomInt(650, 800);
        const gameTime = getRandomInt(110, 135);
        
        const delay = gameTime * 0.6 * 1000; 

        const patchPayload = {
            score,
            gameTime
        };

        const scoreUrl = 'https://api.bybitcoinsweeper.com/api/users/score';

        try {
            const patchResponse = await axios.patch(scoreUrl, patchPayload, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${accessToken}`,
                    'User-Agent': userAgent
                }
            });
            console.log(`    [v] Score updated for Account ${accountIndex + 1}:`, patchResponse.data);
            await new Promise(resolve => setTimeout(resolve, 20000)); 
        } catch (error) {
            if (error.response && error.response.status === 429) {
                console.warn(`[R] Rate limit exceeded for Account ${accountIndex + 1}. Retrying after delay...`);
                await new Promise(resolve => setTimeout(resolve, 30000));
                i--; 
                continue; 
            } else {
                console.error(`[x] Error updating score for Account ${accountIndex + 1}:`, error.message);
            }
        }

        await new Promise(resolve => setTimeout(resolve, delay));
    }
};

const fetchRandomUserAgent = async () => {
    try {
        const response = await axios.get('https://randua.somespecial.one/');
        console.log(`[~] User-Agent:\n${response.data}`);
        return response.data;
    } catch (error) {
        console.error('Error fetching random User-Agent:', error.message);
        return 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'; // Default User-Agent
    }
};

const processAccounts = async (accounts) => {
    while (true) { 
        for (let index = 0; index < accounts.length; index++) {
            const line = accounts[index].trim();
            if (line) { 
                const params = new URLSearchParams(line);
                const user = JSON.parse(decodeURIComponent(params.get('user')));

                const payload = {
                    firstName: user.first_name,
                    lastName: user.last_name,
                    telegramId: String(user.id),
                    userName: user.username
                };

                const loginUrl = 'https://api.bybitcoinsweeper.com/api/auth/login';

                const userAgent = await fetchRandomUserAgent();

                try {
                    const response = await axios.post(loginUrl, payload, {
                        headers: {
                            'Content-Type': 'application/json',
                            'Accept': 'application/json',
                            'User-Agent': userAgent
                        }
                    });

                    const { accessToken, firstName, lastName, telegramId, score } = response.data;

                    console.log(`[~] Logged in for Account ${index + 1}\n[~] Access Token:\n${accessToken}`);
                    console.log(`[~] Detail ${index + 1}:`);
                    console.log(`    Name: ${firstName} ${lastName}`);
                    console.log(`    Telegram ID: ${telegramId}`);
                    console.log(`    Score: ${score}`);

                    await updateScore(accessToken, index, userAgent);
                } catch (error) {
                    if (error.response) {
                        console.error(`[x] Error for Account ${index + 1}:`, error.response.status, error.response.data);
                    } else {
                        console.error('[x] Error:', error.message);
                    }
                }
            }
        }
    }
};

fs.readFile('auth.txt', 'utf8', async (err, data) => {
    if (err) {
        console.error('[x] Error reading auth.txt:', err);
        return;
    }

    const lines = data.split('\n'); 

    await processAccounts(lines);
});